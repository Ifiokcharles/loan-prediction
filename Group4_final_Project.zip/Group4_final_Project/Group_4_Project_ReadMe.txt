1) Run code from line 1 to line 17.
2) Run code from line 18 to line 214.
3) Run code from line 215 to line 227.
4) Run code from line 228 to line 448.